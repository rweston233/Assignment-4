-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema assign04
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema assign04
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `assign04` DEFAULT CHARACTER SET utf8 ;
USE `assign04` ;

-- -----------------------------------------------------
-- Table `assign04`.`members`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`members` ;

CREATE TABLE IF NOT EXISTS `assign04`.`members` (
  `member_ID` INT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(45) NOT NULL,
  `email_conformation` TINYTEXT NULL,
  `firstName` VARCHAR(45) NOT NULL,
  `lastName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`member_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`login`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`login` ;

CREATE TABLE IF NOT EXISTS `assign04`.`login` (
  `login_ID` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`login_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`events`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`events` ;

CREATE TABLE IF NOT EXISTS `assign04`.`events` (
  `eventID` INT NOT NULL AUTO_INCREMENT,
  `event_title` VARCHAR(45) NOT NULL,
  `event_description` VARCHAR(255) NULL,
  `event_date` DATETIME NOT NULL,
  PRIMARY KEY (`eventID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`blog`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`blog` ;

CREATE TABLE IF NOT EXISTS `assign04`.`blog` (
  `blogID` INT NOT NULL AUTO_INCREMENT,
  `blog_content` VARCHAR(255) NOT NULL,
  `blog_comment` VARCHAR(45) NULL,
  `written_by` VARCHAR(45) NULL,
  PRIMARY KEY (`blogID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`contact`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`contact` ;

CREATE TABLE IF NOT EXISTS `assign04`.`contact` (
  `contact_ID` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`contact_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`article`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`article` ;

CREATE TABLE IF NOT EXISTS `assign04`.`article` (
  `article_ID` INT NOT NULL AUTO_INCREMENT,
  `article_title` VARCHAR(45) NOT NULL,
  `atricle_content` VARCHAR(255) NOT NULL,
  `publish_date` DATE NOT NULL,
  PRIMARY KEY (`article_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`alumni`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`alumni` ;

CREATE TABLE IF NOT EXISTS `assign04`.`alumni` (
  `alumni_ID` INT NOT NULL AUTO_INCREMENT,
  `firstName` VARCHAR(45) NOT NULL,
  `lastName` VARCHAR(45) NOT NULL,
  `gradDate` DATE NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`alumni_ID`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`alumni_has_article`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`alumni_has_article` ;

CREATE TABLE IF NOT EXISTS `assign04`.`alumni_has_article` (
  `alumni_alumni_ID` INT NOT NULL,
  `article_article_ID` INT NOT NULL,
  PRIMARY KEY (`alumni_alumni_ID`, `article_article_ID`),
  INDEX `fk_alumni_has_article_article1_idx` (`article_article_ID` ASC) VISIBLE,
  INDEX `fk_alumni_has_article_alumni1_idx` (`alumni_alumni_ID` ASC) VISIBLE,
  CONSTRAINT `fk_alumni_has_article_alumni1`
    FOREIGN KEY (`alumni_alumni_ID`)
    REFERENCES `assign04`.`alumni` (`alumni_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_alumni_has_article_article1`
    FOREIGN KEY (`article_article_ID`)
    REFERENCES `assign04`.`article` (`article_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`events_has_alumni`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`events_has_alumni` ;

CREATE TABLE IF NOT EXISTS `assign04`.`events_has_alumni` (
  `events_eventID` INT NOT NULL,
  `alumni_alumni_ID` INT NOT NULL,
  PRIMARY KEY (`events_eventID`, `alumni_alumni_ID`),
  INDEX `fk_events_has_alumni_alumni1_idx` (`alumni_alumni_ID` ASC) VISIBLE,
  INDEX `fk_events_has_alumni_events1_idx` (`events_eventID` ASC) VISIBLE,
  CONSTRAINT `fk_events_has_alumni_events1`
    FOREIGN KEY (`events_eventID`)
    REFERENCES `assign04`.`events` (`eventID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_events_has_alumni_alumni1`
    FOREIGN KEY (`alumni_alumni_ID`)
    REFERENCES `assign04`.`alumni` (`alumni_ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`updates`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`updates` ;

CREATE TABLE IF NOT EXISTS `assign04`.`updates` (
  `update_ID` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`update_ID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `assign04`.`stats`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `assign04`.`stats` ;

CREATE TABLE IF NOT EXISTS `assign04`.`stats` (
  `stat_ID` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`stat_ID`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
