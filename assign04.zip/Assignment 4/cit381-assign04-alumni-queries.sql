-- #1 return all article titles that have been published before Nov. 15
SELECT 
article_title
FROM article
WHERE publish_date <= '2020-11-15';


-- #2 count the number of alumni that have the last name that starts with "W"
Select count(*) 
FROM alumni
WHERE lastName LIKE 'W%';


-- #3 return all evnet titles that talk about HTML in the desripotion and happen before or on Nov. 15 at 14:00
SELECT *
-- eventID, event_title 
FROM events
WHERE event_description LIKE '%HTML%' AND event_date <= '2020-11-15 14:00:00';

-- #4 give author names who contributed to article ID #3 and display their name and article title
select 
-- alumni_alumni_ID as 'Almuni ID #' , article_article_ID as 'Article ID #',
concat(al.firstName, ', ', al.lastName) as 'Author Name',
ar.article_title as 'article'
 FROM alumni_has_article aha
 inner join alumni al on aha.alumni_alumni_ID = al.alumni_ID
 inner join article ar on aha.article_article_ID = ar.article_ID
where article_article_ID = 3;

-- #5 return the name of alumni members that graduated before the year 2000
SELECT concat(firstName, ', ', lastName) AS 'Alumni name' , gradDate AS 'Graduation day'
FROM alumni WHERE gradDate IN 
(SELECT gradDate 
FROM alumni 
WHERE gradDate <= '2000-01-01'); 