-- events data
SELECT * FROM assign04.events;
INSERT INTO `assign04`.`events` (`event_title`, `event_description`, `event_date`) VALUES ('HTML', 'learn the basics to HTML ', '2020-11-05 14:00:00');
INSERT INTO `assign04`.`events` (`event_title`, `event_description`, `event_date`) VALUES ('JavaScript', 'learn the basics to JavaSript', '2020-11-10 14:00:00');
INSERT INTO `assign04`.`events` (`event_title`, `event_description`, `event_date`) VALUES ('HTML & JS', 'learn how to embed JS into HTML', '2020-11-15 14:00:00');
INSERT INTO `assign04`.`events` (`event_title`, `event_description`, `event_date`) VALUES ('SQL ', 'learn the basics to SQL', '2020-11-20 14:00:00');
INSERT INTO `assign04`.`events` (`event_title`, `event_description`, `event_date`) VALUES ('SQL & Databases ', 'learn how to embed SQl into website databases', '2020-11-25 14:00:00');

-- alumni data
SELECT * FROM assign04.alumni;
INSERT INTO `assign04`.`alumni` (`firstName`, `lastName`, `gradDate`, `email`) VALUES ('River', 'Weston', '2017-06-08', 'river@gmail.com');
INSERT INTO `assign04`.`alumni` (`firstName`, `lastName`, `gradDate`, `email`) VALUES ('Julia', 'Willson', '1970-06-08', 'jj@uoregon.edu');
INSERT INTO `assign04`.`alumni` (`firstName`, `lastName`, `gradDate`, `email`) VALUES ('John', 'Smith', '1995-06-08', 'smithj@uoregon.edu');
INSERT INTO `assign04`.`alumni` (`firstName`, `lastName`, `gradDate`, `email`) VALUES ('Charlotte', 'Schroeder', '1980-06-08', 'char@yhaoo.com');
INSERT INTO `assign04`.`alumni` (`firstName`, `lastName`, `gradDate`, `email`) VALUES ('Anika', 'Bennett', '1965-06-08', 'benA@uroegon.edu');

-- article data
SELECT * FROM assign04.article;
INSERT INTO `assign04`.`article` (`article_title`, `atricle_content`, `publish_date`) VALUES ('HTML', 'Html web page building ', '2020-11-05');
INSERT INTO `assign04`.`article` (`article_title`, `atricle_content`, `publish_date`) VALUES ('JavaSript', 'JS writting tips and tricks', '2020-11-10');
INSERT INTO `assign04`.`article` (`article_title`, `atricle_content`, `publish_date`) VALUES ('HTML & JavaSript', 'embeding JS into HTML', '2020-11-15');
INSERT INTO `assign04`.`article` (`article_title`, `atricle_content`, `publish_date`) VALUES ('SQL', 'SQL cheat sheet ', '2020-11-20');
INSERT INTO `assign04`.`article` (`article_title`, `atricle_content`, `publish_date`) VALUES ('SQL and websites', 'SQL and website pages ', '2020-11-05');

-- member data
SELECT * FROM assign04.members;
INSERT INTO `assign04`.`members` (`email`, `email_conformation`, `firstName`, `lastName`) VALUES ('applle@apple.com', 'yes', 'Johnny', 'Apple');
INSERT INTO `assign04`.`members` (`email`, `email_conformation`, `firstName`, `lastName`) VALUES ('sheep@gamil.com', 'yes', 'Tim', 'Sheep');
INSERT INTO `assign04`.`members` (`email`, `email_conformation`, `firstName`, `lastName`) VALUES ('ewhite@yahoo.com', 'yes', 'Emily ', 'White');
INSERT INTO `assign04`.`members` (`email`, `email_conformation`, `firstName`, `lastName`) VALUES ('jthekid@uoregon.edu', 'no', 'Jason', 'Kid');
INSERT INTO `assign04`.`members` (`email`, `email_conformation`, `firstName`, `lastName`) VALUES ('buckets@nba.org', 'yes', 'LeBron', 'Atikson');


-- alumni_has_article data 
SELECT * FROM assign04.alumni_has_article;
INSERT INTO `assign04`.`alumni_has_article` (`alumni_alumni_ID`, `article_article_ID`) VALUES ('4', '1');
INSERT INTO `assign04`.`alumni_has_article` (`alumni_alumni_ID`, `article_article_ID`) VALUES ('1', '2');
INSERT INTO `assign04`.`alumni_has_article` (`alumni_alumni_ID`, `article_article_ID`) VALUES ('2', '2');
INSERT INTO `assign04`.`alumni_has_article` (`alumni_alumni_ID`, `article_article_ID`) VALUES ('1', '3');
INSERT INTO `assign04`.`alumni_has_article` (`alumni_alumni_ID`, `article_article_ID`) VALUES ('5', '3');
INSERT INTO `assign04`.`alumni_has_article` (`alumni_alumni_ID`, `article_article_ID`) VALUES ('3', '4');
INSERT INTO `assign04`.`alumni_has_article` (`alumni_alumni_ID`, `article_article_ID`) VALUES ('5', '5');

-- events_has_alumni data 
SELECT * FROM assign04.events_has_alumni;
INSERT INTO `assign04`.`events_has_alumni` (`events_eventID`, `alumni_alumni_ID`) VALUES ('1', '5');
INSERT INTO `assign04`.`events_has_alumni` (`events_eventID`, `alumni_alumni_ID`) VALUES ('2', '4');
INSERT INTO `assign04`.`events_has_alumni` (`events_eventID`, `alumni_alumni_ID`) VALUES ('3', '3');
INSERT INTO `assign04`.`events_has_alumni` (`events_eventID`, `alumni_alumni_ID`) VALUES ('4', '2');
INSERT INTO `assign04`.`events_has_alumni` (`events_eventID`, `alumni_alumni_ID`) VALUES ('5', '1');